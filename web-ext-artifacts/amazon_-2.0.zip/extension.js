const address = document.getElementById('nav-global-location-slot'); 
const name = document.getElementById('nav-link-accountList-nav-line-1');
const address2 = document.getElementById('contextualIngressPtLabel');
address.remove();
name.remove();
address2.remove();